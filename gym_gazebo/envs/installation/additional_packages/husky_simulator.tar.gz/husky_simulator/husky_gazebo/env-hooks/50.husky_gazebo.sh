export HUSKY_GAZEBO_DESCRIPTION=$(catkin_find --without-underlays --first-only husky_gazebo urdf/description.gazebo.xacro 2>/dev/null)
